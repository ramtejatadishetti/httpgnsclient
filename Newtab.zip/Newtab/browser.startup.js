
HTTP_GNS_SERVER = "http://ec2-54-91-3-11.compute-1.amazonaws.com:24703/GNS/"
LOOKUP_GUID = "lookupguid?name="
READ_IP_GIVEN_GUID = "read?field=ip&guid="

HTTP_HEAD = "http://"
GOOGLE_HEAD = "https://www.google.com/search?q="
GNS_HEAD = "http://gns3.com/?q="
GNS2_HEAD = "http://gns2.com/?q="

READ_GUID_ERROR = "unable to get guid";
READ_IP_ERROR = "unable to read ip value";
HTTP_ERROR = "http error while making request";
JQUERY_READY = "jquery is loaded";


TIMEOUT_MS = 3000

function make_dotted_string(str) {
    return str.replace("+", " ");
}


function make_string_with_plus(str) {
    return str.replace(" ", "+");
}

function check_error_in_result(result) {
    if( result.includes("+NO+") || result.includes("+GENERICERROR+") || result.includes("+ACCESS_DENIED+") ) 
        return true;
    else
        return false;
}

function get_final_url(search_string) {

    string_with_plus = make_string_with_plus(search_string); 
    final_redirect_url = GOOGLE_HEAD + string_with_plus;

    jQuery.ajax({
        url: HTTP_GNS_SERVER + LOOKUP_GUID + search_string,
        crossDomain: true,
        async: false,
        success: function (result) {
            console.log(result);
            if ( check_error_in_result(result)) {
                //debugger;
                console.log(READ_GUID_ERROR); 
            }
            else {
                //debugger;
                guid = result;
                jQuery.ajax({
                    url: HTTP_GNS_SERVER + READ_IP_GIVEN_GUID + guid,
                    crossDomain: true,
                    async: false,
                    success: function(result){
                        if (check_error_in_result(result)){
                            //debugger;
                            console.log(READ_IP_ERROR);
                        }
                        else {
                            //debugger;
                            final_redirect_url = HTTP_HEAD + result;
                            console.log(final_redirect_url);
                        }
                    },
                    error: function(result) {
                        console.log(HTTP_ERROR);
                    }
                });                
            }
        },
        error: function (result) {
            console.log(HTTP_ERROR);
        }
    });

    return final_redirect_url;
}

chrome.webRequest.onBeforeRequest.addListener(function (details) {
    //console.log(details.url);
    if (details.url.startsWith(GNS_HEAD)) {
        debugger;
        url_string = details.url;
        total_String = url_string.split(GNS_HEAD);
        pre_query = total_String[1];

        search_tokens = pre_query.split('+')
        search_string = ''
        for (i = 0; i < search_tokens.length; i++) {
            search_string += search_tokens[i] + " ";
        }

        final_redirect_url = "";
        if (jQuery) {

            console.log(JQUERY_READY);
            final_redirect_url = get_final_url(search_string);
        }

        return { redirectUrl: final_redirect_url };
    }

}, {
        urls: ['<all_urls>'], // or <all_urls>
        types: ['main_frame', 'sub_frame'],
    }, ['blocking']);




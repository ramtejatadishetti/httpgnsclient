$(document).ready(function(){
        
    //$.fileDownload(TLD_URL)
    //    .done(function () { alert('File download a success!'); })
    //    .fail(function () { alert('File download failed!'); });
    
    /*chrome.downloads.download({
        url: TLD_URL
     // Optional
    });*/

    

    /*$.ajax({
        type:     "GET",
        url:      TLD_URL, // <-- Here
        beforeSend: function(xhr) {
             xhr.setRequestHeader("origin", "")
        },
        success: function(data){
            debugger;
            console.log(data);
        },
         error:function(e){
             debugger;
         }
    });*/

    $.getJSON(TLD_URL, function(data){
        console.log(data.contents);
        alert(data.contents);
    });

   
    $( "#search-form" ).submit(function( event ) {
        var search_query = $("#input-query").val();
        search_query = format_query(search_query);
        
        var result = validate_search_query(search_query);

        debugger;
        window.location.href = "http://gns3.com/?q=" + search_query
        //get_final_url(search_string)

        event.preventDefault();
    });

});
import SimpleHTTPServer
import SocketServer
from urlparse import urlparse

class MyRequestHandler(SimpleHTTPServer.SimpleHTTPRequestHandler):

    def do_GET(self):
        print "Recived get request"
        requested_name_string = urlparse.parse_qs(urlparse.urlparse(self.path).query).get('name', None)
        print requested_name_string

PORT = 8000

Handler = MyRequestHandler

httpd = SocketServer.TCPServer(("", PORT), Handler)

print "serving at port", PORT
httpd.serve_forever()

